#include <stdio.h>

int main() {
    int n;
    printf("Enter the number of elements (including the missing one): ");
    scanf("%d", &n);

    int arr1[n];
    printf("Enter the elements of the array:\n");
    for (int i = 0; i < n - 1; i++) {
        scanf("%d", &arr1[i]);
    }

    for (int i = 0; i < n - 1; i++) {
        int j;
        for (j = i + 1; j < n - 1; j++) {
            if (arr1[i] == arr1[j]) {
                arr1[j] = arr1[n - 2];
                n--;
                break;
            }
        }
    }

    int missing_sum = (n * (n + 1)) / 2;
    for (int i = 0; i < n - 1; i++) {
        missing_sum -= arr1[i];
    }

    printf("Missing number: %d\n", missing_sum);

    return 0;
}
